package com.INOapp

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class InOappApplicationTests {

	@Test
	fun contextLoads() {
	}

}
