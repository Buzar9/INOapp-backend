package com.INOapp

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class InOappApplication

fun main(args: Array<String>) {
	runApplication<InOappApplication>(*args)
}
